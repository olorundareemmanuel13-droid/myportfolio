# Emmanuel Olorundare — Portfolio Site

A static, dependency-free portfolio site (HTML/CSS/JS). No build step, no
framework, no backend — it just needs to be hosted as static files.

## File structure

```
index.html            The whole site (one page, section-anchored nav)
css/styles.css         All styles (design tokens at the top of the file)
js/data.js             Auto-generated content data — every work item &
                        video, with its title/description/category
js/main.js              Gallery rendering, filters, lightbox, nav behaviour
assets/img/portrait.webp   Hero portrait
assets/img/favicon.svg     Favicon
assets/img/thumb/*.webp    Gallery thumbnails (small, fast-loading)
assets/img/full/*.webp     Full-size images (shown in the lightbox)
assets/video/*.mp4         Compressed motion/video clips
assets/video/*.jpg         Poster frames for each video
robots.txt
```

## Deploying it

This is plain static files, so it works on any static host:

- **Netlify / Vercel**: drag-and-drop the whole folder, or connect a repo.
- **GitHub Pages**: push this folder to a repo and enable Pages.
- **Any web server**: copy the folder to your web root (e.g. `public_html`).

There's no `npm install` or build command needed — `index.html` references
the CSS/JS/assets with relative paths, so the folder works as-is.

## Editing content

- **Text** (hero copy, about, services, contact info): edit directly in
  `index.html`.
- **Portfolio images**: each item lives in `js/data.js` as an object with
  `title`, `desc`, `cat` (`brand` / `social` / `print`), `thumb` and `full`
  paths. Add, remove or re-order objects in the `PORTFOLIO_ITEMS` array to
  change the gallery — the grid and filters rebuild from this automatically.
- **Videos**: same idea, in the `VIDEO_ITEMS` array.
- **Colours/fonts**: the top of `css/styles.css` has all colour and font
  variables in one place (`:root { ... }`).

## Before going live

- Update the placeholder `og:image` / meta tags in `index.html` with your
  real domain once you have one, and add a `<link rel="canonical">` tag
  (there's a comment showing where).
- The contact form uses a `mailto:` submission (there's no backend), so it
  opens the visitor's email app with the message pre-filled. If you'd
  rather collect submissions server-side, swap the form's `action` for a
  form service (e.g. Formspree) or your own endpoint.
