(function () {
  "use strict";

  document.getElementById("year").textContent = new Date().getFullYear();

  /* ---------------- Header scroll state ---------------- */
  var header = document.getElementById("site-header");
  function onScroll() {
    if (window.scrollY > 12) header.classList.add("is-scrolled");
    else header.classList.remove("is-scrolled");
  }
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });

  /* ---------------- Mobile nav ---------------- */
  var navToggle = document.getElementById("nav-toggle");
  var mobileNav = document.getElementById("mobile-nav");
  navToggle.addEventListener("click", function () {
    var open = mobileNav.classList.toggle("is-open");
    navToggle.setAttribute("aria-expanded", open ? "true" : "false");
  });
  mobileNav.querySelectorAll("a").forEach(function (a) {
    a.addEventListener("click", function () {
      mobileNav.classList.remove("is-open");
      navToggle.setAttribute("aria-expanded", "false");
    });
  });

  /* ---------------- Build gallery ---------------- */
  var EXCLUDED_GROUPS = ["hey-africa", "rich-atomweaves"];
  var gridItems = PORTFOLIO_ITEMS.filter(function (it) {
    return EXCLUDED_GROUPS.indexOf(it.group) === -1;
  });

  var galleryEl = document.getElementById("gallery");
  var galleryFrag = document.createDocumentFragment();

  gridItems.forEach(function (item, idx) {
    var el = document.createElement("button");
    el.type = "button";
    el.className = "gallery-item";
    el.setAttribute("data-cat", item.cat);
    el.setAttribute("data-index", idx);
    el.setAttribute("aria-label", "View " + item.title + " — " + catLabel(item.cat));
    el.innerHTML =
      '<img src="' + item.thumb + '" alt="' + escapeHtml(item.title) + '" loading="lazy" width="' + item.w + '" height="' + item.h + '">' +
      '<span class="gallery-item__overlay"><span><h3>' + escapeHtml(item.title) + "</h3>" +
      "<span>" + catLabel(item.cat) + "</span></span></span>";
    el.addEventListener("click", function () {
      openLightbox(gridItems, idx);
    });
    galleryFrag.appendChild(el);
  });
  galleryEl.appendChild(galleryFrag);

  function catLabel(cat) {
    return { brand: "Brand & logo", social: "Social & campaign", print: "Print & merch" }[cat] || cat;
  }
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  /* ---------------- Filters ---------------- */
  var filterBtns = document.querySelectorAll(".filter-btn");
  filterBtns.forEach(function (btn) {
    btn.addEventListener("click", function () {
      filterBtns.forEach(function (b) { b.classList.remove("is-active"); });
      btn.classList.add("is-active");
      var filter = btn.getAttribute("data-filter");
      document.querySelectorAll(".gallery-item").forEach(function (card) {
        var show = filter === "all" || card.getAttribute("data-cat") === filter;
        card.classList.toggle("is-hidden", !show);
      });
    });
  });

  /* ---------------- Spotlight mini-galleries ---------------- */
  function buildSpotlight(group, mainImgId, thumbsId) {
    var items = PORTFOLIO_ITEMS.filter(function (it) { return it.group === group; });
    var mainImg = document.getElementById(mainImgId);
    var thumbsEl = document.getElementById(thumbsId);
    items.forEach(function (item, i) {
      var t = document.createElement("img");
      t.src = item.thumb;
      t.alt = item.title;
      t.loading = "lazy";
      if (i === 0) t.classList.add("is-active");
      t.addEventListener("click", function () {
        mainImg.src = item.full;
        mainImg.alt = item.title;
        thumbsEl.querySelectorAll("img").forEach(function (x) { x.classList.remove("is-active"); });
        t.classList.add("is-active");
      });
      thumbsEl.appendChild(t);
    });
    // whole spotlight also openable in full lightbox
    mainImg.style.cursor = "pointer";
    mainImg.addEventListener("click", function () {
      var startIdx = items.findIndex(function (it) { return it.full === mainImg.getAttribute("src"); });
      openLightbox(items, startIdx === -1 ? 0 : startIdx);
    });
  }
  buildSpotlight("hey-africa", "spotlight-hey-africa-main", "spotlight-hey-africa-thumbs");
  buildSpotlight("rich-atomweaves", "spotlight-rich-main", "spotlight-rich-thumbs");

  /* ---------------- Video grid ---------------- */
  var videoGrid = document.getElementById("video-grid");
  VIDEO_ITEMS.forEach(function (v, idx) {
    var el = document.createElement("button");
    el.type = "button";
    el.className = "video-card";
    el.setAttribute("aria-label", "Play " + v.title);
    el.innerHTML =
      '<img src="' + v.poster + '" alt="" loading="lazy" width="1280" height="720">' +
      '<span class="video-card__play"><span>Play</span></span>' +
      '<span class="video-card__label">' + escapeHtml(v.title) + "</span>";
    el.addEventListener("click", function () {
      openLightboxVideo(v);
    });
    videoGrid.appendChild(el);
  });

  /* ---------------- Lightbox ---------------- */
  var lightbox = document.getElementById("lightbox");
  var lbImg = document.getElementById("lightbox-img");
  var lbVideo = document.getElementById("lightbox-video");
  var lbTitle = document.getElementById("lightbox-title");
  var lbDesc = document.getElementById("lightbox-desc");
  var lbClose = document.getElementById("lightbox-close");
  var lbPrev = document.getElementById("lightbox-prev");
  var lbNext = document.getElementById("lightbox-next");

  var currentSet = null;
  var currentIdx = 0;
  var lastFocused = null;

  function openLightbox(set, idx) {
    currentSet = set;
    currentIdx = idx;
    lastFocused = document.activeElement;
    renderLightbox();
    show();
  }

  function openLightboxVideo(v) {
    currentSet = null;
    lastFocused = document.activeElement;
    lbImg.hidden = true;
    lbVideo.hidden = false;
    lbVideo.src = v.video;
    lbVideo.poster = v.poster;
    lbVideo.load();
    lbTitle.textContent = v.title;
    lbDesc.textContent = v.desc;
    lbPrev.style.display = "none";
    lbNext.style.display = "none";
    show();
    lbVideo.play().catch(function () {});
  }

  function renderLightbox() {
    var item = currentSet[currentIdx];
    lbVideo.pause();
    lbVideo.hidden = true;
    lbImg.hidden = false;
    lbImg.src = item.full;
    lbImg.alt = item.title;
    lbTitle.textContent = item.title;
    lbDesc.textContent = item.desc || "";
    lbPrev.style.display = currentSet.length > 1 ? "flex" : "none";
    lbNext.style.display = currentSet.length > 1 ? "flex" : "none";
  }

  function show() {
    lightbox.hidden = false;
    document.body.style.overflow = "hidden";
    lbClose.focus();
    document.addEventListener("keydown", onKeydown);
  }
  function hide() {
    lightbox.hidden = true;
    document.body.style.overflow = "";
    lbVideo.pause();
    lbVideo.removeAttribute("src");
    document.removeEventListener("keydown", onKeydown);
    if (lastFocused) lastFocused.focus();
  }

  function next() {
    if (!currentSet) return;
    currentIdx = (currentIdx + 1) % currentSet.length;
    renderLightbox();
  }
  function prev() {
    if (!currentSet) return;
    currentIdx = (currentIdx - 1 + currentSet.length) % currentSet.length;
    renderLightbox();
  }

  function onKeydown(e) {
    if (e.key === "Escape") hide();
    else if (e.key === "ArrowRight") next();
    else if (e.key === "ArrowLeft") prev();
    else if (e.key === "Tab") trapFocus(e);
  }

  function trapFocus(e) {
    var focusables = lightbox.querySelectorAll("button");
    var first = focusables[0];
    var last = focusables[focusables.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }

  lbClose.addEventListener("click", hide);
  lbNext.addEventListener("click", next);
  lbPrev.addEventListener("click", prev);
  lightbox.addEventListener("click", function (e) {
    if (e.target === lightbox) hide();
  });

  /* ---------------- Contact form (mailto fallback, no backend) ---------------- */
  var form = document.getElementById("contact-form");
  form.addEventListener("submit", function () {
    // Native mailto submit handles this; nothing else to do without a backend.
  });
})();
